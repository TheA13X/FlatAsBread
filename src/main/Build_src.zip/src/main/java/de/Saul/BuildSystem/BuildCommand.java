package de.Saul.BuildSystem;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BuildCommand implements CommandExecutor {

	public BuildCommand(BuildSystem plugin) {
		plugin.getCommand("build").setExecutor(this);
//		CommandMethod.commandRegister("build");
	}

	public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args) {
		
		if (!(sender instanceof Player)) {
			
			accept(sender, args);
			return true;
		}
		
//		Player p = (Player) sender;
		
//		Perm
		if (sender.isOp()) {
			
			accept(sender, args);
			return true;
		}
		
		return false;
	}
	
	private void accept(CommandSender sender, String[] args) {
//		String map;
		
		if (args.length > 0) {
			if (args[0].equalsIgnoreCase("map")) {
				if (args.length > 1) {
					if (args[1].equalsIgnoreCase("list")) {
												
					} else if (args[1].equalsIgnoreCase("create")) {
						
					} else if (args[1].equalsIgnoreCase("delete")) {
						
					} else if (args[1].equalsIgnoreCase("load")) {
						
					} else if (args[1].equalsIgnoreCase("save")) {
						
					} else {
						sender.sendMessage("/world map <list/create/delete/load/save>");
					}
				} else {
					sender.sendMessage("/world map <list/create/delete/load/save>");
				}
			} else if (args[0].equalsIgnoreCase("gs")) {
				if (args.length > 1) {
					
				}
			} else {
				sender.sendMessage("/build <map/gs>");
			}
		} else {
			sender.sendMessage("/build <map/gs>");
		}
	}
}
