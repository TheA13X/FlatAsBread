package de.Saul.BuildSystem;

import java.sql.ResultSet;
import java.sql.SQLException;

import de.Saul.CloudSystem.MySQL.MySQLMethod;

public class MapTable {
	
	public static void load() {

		String name;
		String spawn;
		int edit;
		String version;
		
		ResultSet result_map = MySQLMethod.select("SELECT * FROM map;");
		
		try {

			while (result_map.next()) {
	        	
	        	name = result_map.getString("name");
	        	spawn = result_map.getString("spawn");
	        	edit = result_map.getInt("edit");
	        	version = result_map.getString("version");
				
				BuildSystem.map_spawn.put(name, spawn);
				BuildSystem.map_edit.put(name, edit);
				BuildSystem.map_version.put(name, version);
				
	        }
        
		} catch (SQLException err) {
			err.printStackTrace();
		}
	}

}
