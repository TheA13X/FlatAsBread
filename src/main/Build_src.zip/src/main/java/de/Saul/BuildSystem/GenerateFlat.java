package de.Saul.BuildSystem;

import java.util.Random;

import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.generator.ChunkGenerator;

public class GenerateFlat extends ChunkGenerator {
	
	int high = 64;
	int size = 96 + 1;
	int way = 3 + 1;
	int gravel = 3;
	
	@SuppressWarnings("deprecation")
	public byte[][] generateBlockSections(World world, Random random, int chunkX, int chunkZ, BiomeGrid biomeGrid) {
		byte[][] result = new byte[world.getMaxHeight() / 16][];
		
		int x;
		int y;
		int z;
		
	    for (x = 0; x < 16; x++) {
	    	for (z = 0; z < 16; z++) {
	    		biomeGrid.setBiome(x, z, Biome.PLAINS);
	    	}
	    }	 
	    
		for (x = 0; x < 16; x++) {
			for (z = 0; z < 16; z++) {
				setBlock(result, x, 0, z, (byte)Material.BEDROCK.getId());
			}
	    }
		
		for (y = 1; y < 53; y++) {
			for (x = 0; x < 16; x++) {
	    		for (z = 0; z < 16; z++) {
	    			setBlock(result, x, y, z, (byte)Material.STONE.getId());
	    		}
	    	}
	    }
		
		for (y = 53; y < 63; y++) {
			for (x = 0; x < 16; x++) {
	    		for (z = 0; z < 16; z++) {
	    			setBlock(result, x, y, z, (byte)Material.DIRT.getId());
	    		}
	    	}
	    }

	    for (x = 0; x < 16; x++) {
	    	for (z = 0; z < 16; z++) {
	    		setBlock(result, x, 63, z, (byte)Material.GRASS.getId());
	    	}
	    }
	    
	    int real_x = chunkX * 16;
    	int real_z = chunkZ * 16;
	    
	    for (x = 0; x < 16; x++) {
	    	for (z = 0; z < 16; z++) {
	    		
	    		int anzahl_x = (real_x + x) / (size + way);
	    		int rest_x = (anzahl_x * (size + way)) - (real_x + x);
	    		
	    		int anzahl_z = (real_z + z) / (size + way);
	    		int rest_z = (anzahl_z * (size + way )) - (real_z + z);
	    		
	    		int rest_x2 = 0;
				if (rest_x > 0) {
	    			rest_x2 = rest_x - way;
	    		} else if (rest_x < 0) {
	    			rest_x2 = rest_x + way;
	    		}
	    		int rest_z2 = 0;
				if (rest_z > 0) {
	    			rest_z2 = rest_z - way;
	    		} else if (rest_z < 0) {
	    			rest_z2 = rest_z + way;
	    		}
	    		
	    		if (rest_x == 0 || rest_z == 0 || rest_x2 == 0 || rest_z2 == 0) {
	    			setBlock(result, x, high, z, (byte) 44);
	    			setBlock(result, x, high-1, z, (byte) Material.DIRT.getId());
	    		}
	    		
	    		for (int i = 0+1; i < way; i++) {
	    			if (rest_x > 0) {
		    			rest_x2 = rest_x - way + i;
		    		} else if (rest_x < 0) {
		    			rest_x2 = rest_x + way - i;
		    		}// else if (rest_x == 0) {
//		    			rest_x2 = rest_x + way;
//		    		}
					if (rest_z > 0) {
		    			rest_z2 = rest_z - way + i;
		    		} else if (rest_z < 0) {
		    			rest_z2 = rest_z + way - i;
		    		}// else if (rest_z == 0) {
//		    			rest_z2 = rest_z + way;
//		    		}
					
					if (rest_x2 == 0 || rest_z2 == 0) {
						
						int random_int = (int) ((Math.random()*2)+1);
						if (random_int == 1) {
							setBlock(result, x, high - 1, z, (byte) Material.GRAVEL.getId());
						} else if (random_int == 2) {
							setBlock(result, x, high - 1, z, (byte) Material.COBBLESTONE.getId());
						} else if (random_int == 3) {
							setBlock(result, x, high - 1, z, (byte) Material.SMOOTH_BRICK.getId());
						} else if (random_int == 3) {
							setBlock(result, x, high - 1, z, (byte) Material.MOSSY_COBBLESTONE.getId());
						}
		    			
		    			setBlock(result, x, high, z, (byte) Material.AIR.getId());
		    		}
	    		}
	    		if (real_x + x == 0 || real_z + z == 0) {
	    			int random_int = (int) ((Math.random()*2)+1);
					if (random_int == 1) {
						setBlock(result, x, high - 1, z, (byte) Material.GRAVEL.getId());
					} else if (random_int == 2) {
						setBlock(result, x, high - 1, z, (byte) Material.COBBLESTONE.getId());
					}
	    			
	    			setBlock(result, x, high, z, (byte) Material.AIR.getId());
	    		}
	    		
//	    		TODO: gravel weg
	    		
	    		
//		    	if (real_x + x == 0 || real_z + z == 0) {
//		    		setBlock(result, x, 64, z, (byte) Material.DIAMOND_BLOCK.getId());
//		    	}
	    	}
	    }
		
		return result;
	}
	
    void setBlock(byte[][] result, int x, int y, int z, byte blkid) {
        if (result[y >> 4] == null) {
            result[y >> 4] = new byte[4096];
        }
        result[y >> 4][((y & 0xF) << 8) | (z << 4) | x] = blkid;
    }
}
