package de.Saul.BuildSystem;

import java.util.HashMap;

import org.bukkit.WorldCreator;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;

public class BuildSystem extends JavaPlugin {
	
	public static final HashMap<String, String> map_spawn = new HashMap<String, String>();
	public static final HashMap<String, Integer> map_edit = new HashMap<String, Integer>();
	public static final HashMap<String, String> map_version = new HashMap<String, String>();
	
	BuildCommand buildcommand;
	
	GenerateFlat generateflat;
	
	public void onEnable() {
		
		buildcommand = new BuildCommand(this);
		
//		generateflat = new GenerateFlat(this);
		
		WorldCreator worldCreator = new WorldCreator("flat");
		worldCreator.generator(new GenerateFlat());
		worldCreator.createWorld();
//		World world = worldCreator.createWorld();
		
//		WorldCreator world = new WorldCreator("flat");
//		
//		world.generator("GenerateFlat");
		
//		ChunkGenerator getDefaultWorldGenerator(String worldname, String id) {
//		    generateflat = new GenerateFlat(this);
//		}
		
	}
	
	public void onDisable() {
		
	}
	
	@Override
	public ChunkGenerator getDefaultWorldGenerator(String worldName, String id) {
		return new GenerateFlat();
	}
	
//    @EventHandler
//    public void onWorldInit(WorldInitEvent event) {
//        event.getWorld().getPopulators().clear();
//        event.getWorld().getPopulators().add(new Population());
//    }
}
